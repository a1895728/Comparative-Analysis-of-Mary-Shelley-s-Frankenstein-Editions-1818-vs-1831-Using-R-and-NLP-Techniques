README: Function Accuracy Checking

The following book comparisons are being used for accuracy checking of the function:

## The Picture of Dorian Gray 

## Frankenstein (1818) vs Dracula (1897) 

## Treasure Island (1833) vs Kidnapped (1886) 

Make sure to update the necessary parameters and run the function accordingly for each comparison.

