# ================================
# --- Load Libraries ---
# ================================
library(dplyr)
library(ggplot2)
library(readr)
library(reticulate)

# ================================
# --- Setup Python & Transformers Model ---
# ================================
Sys.setenv(RETICULATE_PYTHON = "C:/Users/User/anaconda3/envs/transforEmotion/python.exe")
use_python("C:/Users/User/anaconda3/envs/transforEmotion/python.exe", required = TRUE)

transformers <- import("transformers")
pipeline <- transformers$pipeline

sentiment_model <- pipeline(
  task = "sentiment-analysis",
  model = "siebert/sentiment-roberta-large-english"
)

# ================================
# --- Load Input Data ---
# ================================
frankenstein_sentences <- read_csv("Tables/frankenstein_sentences_with_group.csv")

# ================================
# --- Expand Long Sentences (optional) ---
# ================================
split_long_sentence <- function(sentence, max_chars = 500) {
  if (nchar(sentence) <= max_chars) {
    return(sentence)
  } else {
    strwrap(sentence, width = max_chars, simplify = TRUE)
  }
}

frankenstein_sentences_expanded <- frankenstein_sentences %>%
  rowwise() %>%
  mutate(sentence = list(split_long_sentence(sentence))) %>%
  unnest(sentence) %>%
  ungroup()

# ================================
# --- Run Sentiment Analysis ---
# ================================
analyze_sentiment <- function(texts, model) {
  results <- lapply(texts, function(x) {
    out <- model(x)[[1]]
    data.frame(
      label = out$label,
      score = out$score
    )
  })
  do.call(rbind, results)
}

sentiment_raw <- analyze_sentiment(frankenstein_sentences_expanded$sentence, sentiment_model)

# ================================
# --- Combine Metadata + Sentiment ---
# ================================
sentiment_results <- bind_cols(
  frankenstein_sentences_expanded[, c("book", "chapter", "sentence", "group_no", "theme")],
  sentiment_raw
)

write_csv(sentiment_results, "Tables/Sentiment_result_non-lexicon.csv")

# ================================
# --- Compute Sentiment Score ---
# ================================
sentiment_results <- sentiment_results %>%
  mutate(sentiment_score = ifelse(label == "POSITIVE", 1, -1))

# ================================
# --- Group-wise Sentiment ---
# ================================
sentiment_group <- sentiment_results %>%
  group_by(book, group_no, theme) %>%
  summarise(
    avg_sentiment = mean(sentiment_score),
    .groups = "drop"
  )

# ================================
# --- Plot ---
# ================================
sentiment_group_plot_non_lexicon <- ggplot(sentiment_group, aes(x = group_no, y = avg_sentiment, color = book)) +
  geom_line(linewidth = 1) +
  geom_point(size = 2) +
  scale_x_continuous(breaks = 1:13) +
  labs(
    title = "Group-wise Sentiment(non-lexicon) in Frankenstein Editions",
    x = "Narrative Group Number", y = "Average Sentiment Score", color = "Edition"
  ) +
  theme_minimal(base_size = 13)

print(sentiment_group_plot_non_lexicon)
ggsave("EPS_Graphs/sentiment_by_group_non-lexicon.eps", plot = sentiment_group_plot_non_lexicon, device = "eps", width = 8, height = 5)


