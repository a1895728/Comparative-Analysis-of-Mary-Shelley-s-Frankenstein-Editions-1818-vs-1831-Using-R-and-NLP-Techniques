
README: How to Run Sentiment Analysis Non Lexicon Code (for R Users)

Overview
This R script runs sentiment analysis on sentences from *Frankenstein* using a pre-trained model in Python. The sentiment analysis model is powered by the `transformers` library in Python. This README will guide you step-by-step to set up the necessary environment for running the script and integrating Python with R using the `reticulate` package.

Requirements
Before running the script, you need:
1. **R (and RStudio) installed on your computer**
2. **Anaconda** (or Python) installed, which will be used to run the sentiment analysis model
3. **Python Packages**: `transformers`, `torch`, `pandas`

Step 1: Setting Up Python and Required Libraries

Create a Python Environment:
1. Open **Anaconda Navigator**.
2. Go to the **Environments** tab.
3. Click **Create** to set up a new environment.
   - **Name**: `transforEmotion`
   - **Python version**: 3.8 (or the version specified in the script).
   - Click **Create**.

Install Required Python Packages:
Once the environment is set up:
1. Select the `transforEmotion` environment.
2. In **Anaconda Navigator**, go to the **Home** tab and make sure `transforEmotion` environment is selected.
3. Install the required packages by typing the following commands in the terminal :

   ```bash
   pip install transformers torch pandas
   ```

Step 2: Integrating Python with R Using Reticulate
We will use the **`reticulate`** package in R to run Python code.

1. **Install `reticulate` in R**:
   Open your **RStudio** (or R console) and run:

   ```r
   install.packages("reticulate")
   ```

2. **Configure `reticulate` to Use Python**:
   Tell R to use the Python environment you just created. In the R script, add this line (adjust the path if necessary):

   ```r
   Sys.setenv(RETICULATE_PYTHON = "C:/Users/User/anaconda3/envs/transforEmotion/python.exe")
   library(reticulate)
   use_python("C:/Users/User/anaconda3/envs/transforEmotion/python.exe", required = TRUE)
   ```


